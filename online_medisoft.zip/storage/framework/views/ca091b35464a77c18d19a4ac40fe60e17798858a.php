<?php $__env->startSection('content-header'); ?>
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-sm-6">
				<h1 class="m-0">Add User</h1>
				</div><!-- /.col -->
				<div class="col-sm-6">
					<ol class="breadcrumb float-sm-right">
						<li class="breadcrumb-item"><a href="#">Home</a></li>
						<li class="breadcrumb-item active">User</li>
					</ol>
					</div><!-- /.col -->
					</div><!-- /.row -->
					</div><!-- /.container-fluid -->
				</div>
				<?php $__env->stopSection(); ?>
				<?php $__env->startSection('main-content'); ?>
				<!-- Main content -->
				<section class="content">
					<div class="container-fluid">
						<!-- SELECT2 EXAMPLE -->
						
						<div class="card card-default">
							<div class="card-header">
								<h3 class="card-title">User</h3>
								<div class="card-tools">
									<button type="button" class="btn btn-tool" data-card-widget="collapse">
									<i class="fas fa-minus"></i>
									</button>
									<button type="button" class="btn btn-tool" data-card-widget="remove">
									<i class="fas fa-times"></i>
									</button>
								</div>
							</div>
							<!-- /.card-header -->
							<form action="<?php echo e(route('users.save-user.post')); ?>" method="POST" id="myForm" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<div class="card-body">


									
									
										
											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label for="exampleInputEmail1">First Name</label>
														<input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter First Name" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputPassword1">User Name</label>
														<input type="text" class="form-control" id="exampleInputPassword1" name="user_name" placeholder="Enter User Name" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputPassword1">DOB</label>
														<input type="date" class="form-control" id="dob" name="dob" placeholder="Enter DOB" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputPassword1">Email</label>
														<input type="text" class="form-control" id="email" name="email" placeholder="Enter Email" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputPassword1">Confirmed Password</label>
														<input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Enter Confirmed Password" required="">
													</div>
												</div>
												<div class="col-md-6">
													<div class="form-group">
														<label for="exampleInputEmail1">Last Name</label>
														<input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter Last Name" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputEmail1">Gender</label>
														<select class="form-control select2" style="width: 100%;" name="gender" required="">
															<option selected="" disabled="" value="">Please Select a Gender</option>
															<option value="male">Male</option>
															<option value="female">Female</option>
															<option value="others">Others</option>
														</select>
													</div>
													<div class="form-group">
														<label for="exampleInputEmail1">Mobile Number</label>
														<input type="text" class="form-control" id="mobile_number" name="mobile_number" placeholder="Enter Mobile Number" required="">
													</div>
													<div class="form-group">
														<label for="exampleInputPassword1">Password</label>
														<input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter Password" required="">
													</div>
													<div class="form-group">
														<label>User Type</label>
														<select class="form-control select2" style="width: 100%;" name="user_type" required="">
															<option selected="" disabled="" value="">Please Select a Group</option>
															<option value="Super Admin">Super Admin</option>
															<option value="Admin">Admin</option>
															<option value="Co-Admin">Co-Admin</option>
														</select>
														
													</div>
												</div>
												<!-- /.col -->
											</div>

										

											<div class="row">
												<div class="col-md-6">
													<div class="form-group">
														<label for="exampleInputEmail1">Present Address</label>
														<textarea class="form-control" name="present_address" id="present_address"placeholder="Enter Present Address" required=""></textarea>
													</div>
													
													<div class="form-group">
														<label for="exampleInputFile">Profile Image</label>
														<div class="input-group">
															<div class="custom-file">
																<input type="file" class="custom-file-input" id="exampleInputFile" name="profile_image">
																<label class="custom-file-label" for="exampleInputFile">Choose file</label>
															</div>
															<div class="input-group-append">
																<span class="input-group-text">Upload</span>
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-6">
													<div class="form-group">
														<label for="exampleInputEmail1">Permanent Address</label>
														<textarea class="form-control" name="permanent_address" id="permanent_address" placeholder="Enter Permanent Address"></textarea>
													</div>	
												</div>
												<!-- /.col -->
											</div>
											
											<input type="Submit" value="Submit" class="btn btn-primary">
									
									</div>
								</form>
								</div>
							</div>
							<!-- /.card-body -->
						</div>
						<!-- /.card -->
					</div>
					<!-- /.container-fluid -->
				</section>
				<!-- /.content -->
<!-- <script>
$(document).ready(function(){
  $("#myForm").submit(function(){
    alert("Submitted");
  });
});
</script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Backend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\online_medisoft\resources\views/Backend/users/addUser.blade.php ENDPATH**/ ?>