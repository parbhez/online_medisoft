<footer class="main-footer">
    <strong>Copyright &copy; 2020-2021 <a href="#">Online Medisoft</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar --><?php /**PATH C:\xampp\htdocs\online_medisoft\resources\views/backend/_partials/footer.blade.php ENDPATH**/ ?>